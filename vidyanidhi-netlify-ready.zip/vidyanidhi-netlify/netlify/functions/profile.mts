import { getDatabase } from '@netlify/database';
const db=getDatabase();
export default async ()=>{try{const r=await db.sql`SELECT value FROM site_settings WHERE key='profile_photo' LIMIT 1`;return Response.json({url:r.rows[0]?.value?`/api/file?key=${encodeURIComponent(r.rows[0].value)}`:null})}catch(e){return Response.json({url:null})}};
export const config={path:'/api/profile'};
