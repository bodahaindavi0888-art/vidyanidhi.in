import { getDatabase } from '@netlify/database';
import { isAdmin } from './_auth.mts';
const db=getDatabase();
export default async (req:Request)=>{try{const u=new URL(req.url);const category=u.searchParams.get('category');const sub=u.searchParams.get('subcategory');let rows;if(category&&sub){rows=await db.sql`SELECT * FROM resources WHERE category=${category} AND subcategory=${sub} ORDER BY created_at DESC`;}else if(category){rows=await db.sql`SELECT * FROM resources WHERE category=${category} ORDER BY created_at DESC`;}else{rows=await db.sql`SELECT * FROM resources ORDER BY created_at DESC`;}return Response.json({resources:rows.rows,admin:await isAdmin(req)});}catch(e){console.error(e);return Response.json({error:'Resources load failed'},{status:500})}};
export const config={path:'/api/resources'};
