import { getDatabase } from '@netlify/database';
import { getStore } from '@netlify/blobs';
import { isAdmin } from './_auth.mts';
const db=getDatabase();const store=getStore('vidyanidhi-files');
export default async (req:Request)=>{if(!(await isAdmin(req)))return Response.json({error:'Admin login required'},{status:401});if(req.method!=='DELETE')return Response.json({error:'Method not allowed'},{status:405});try{const id=new URL(req.url).searchParams.get('id');if(!id)return Response.json({error:'id required'},{status:400});const r=await db.sql`SELECT file_key FROM resources WHERE id=${id}`;if(!r.rows.length)return Response.json({error:'Resource not found'},{status:404});const key=r.rows[0].file_key;if(key)await store.delete(key);await db.sql`DELETE FROM resources WHERE id=${id}`;return Response.json({ok:true});}catch(e){console.error(e);return Response.json({error:'Delete failed'},{status:500})}};
export const config={path:'/api/resource'};
