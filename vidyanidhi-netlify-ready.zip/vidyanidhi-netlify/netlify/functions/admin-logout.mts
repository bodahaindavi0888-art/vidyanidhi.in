import { clearCookie } from './_auth.mts';
export default async ()=>new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':clearCookie()}});
export const config={path:'/api/admin/logout'};
