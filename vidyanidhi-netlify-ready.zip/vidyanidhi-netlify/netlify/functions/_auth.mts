const enc = new TextEncoder();
const b64 = (bytes: Uint8Array) => Buffer.from(bytes).toString('base64url');
const fromB64 = (s: string) => new Uint8Array(Buffer.from(s,'base64url'));
async function digest(value:string){return crypto.subtle.digest('SHA-256',enc.encode(value));}
async function hmac(value:string, secret:string){const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(value)));}
export async function passwordOk(password:string){const configured=process.env.ADMIN_PASSWORD_HASH; if(!configured) return false; const d=new Uint8Array(await digest(password)); const actual=b64(d); return actual===configured;}
export async function makeSession(){const secret=process.env.ADMIN_SESSION_SECRET; if(!secret) throw new Error('ADMIN_SESSION_SECRET is not configured'); const payload=b64(enc.encode(JSON.stringify({iat:Date.now(),nonce:crypto.randomUUID()}))); const sig=b64(await hmac(payload,secret)); return `${payload}.${sig}`;}
export async function isAdmin(req:Request){const secret=process.env.ADMIN_SESSION_SECRET; if(!secret) return false; const cookie=req.headers.get('cookie')||''; const m=cookie.match(/(?:^|;\s*)vn_admin=([^;]+)/); if(!m)return false; const [payload,sig]=m[1].split('.'); if(!payload||!sig)return false; const expected=b64(await hmac(payload,secret)); if(expected!==sig)return false; try{const data=JSON.parse(new TextDecoder().decode(fromB64(payload))); return Date.now()-Number(data.iat)<8*60*60*1000}catch{return false}}
export function sessionCookie(token:string){return `vn_admin=${token}; Path=/; Max-Age=28800; HttpOnly; Secure; SameSite=Lax`}
export function clearCookie(){return 'vn_admin=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax'}
