CREATE TABLE IF NOT EXISTS resources (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL,
  subcategory TEXT NOT NULL DEFAULT 'all',
  class_level TEXT,
  resource_type TEXT NOT NULL,
  file_key TEXT,
  file_name TEXT,
  file_url TEXT,
  external_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS resources_category_idx ON resources(category);
CREATE INDEX IF NOT EXISTS resources_subcategory_idx ON resources(subcategory);
CREATE INDEX IF NOT EXISTS resources_created_idx ON resources(created_at DESC);

CREATE TABLE IF NOT EXISTS site_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO resources(id,title,category,subcategory,resource_type,external_url) VALUES
('legacy-1','తెలుగు సంధులు - పూర్తి వివరణ','grammar','all','PDF','https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'),
('legacy-2','సమాసములు & విభక్తులు నోట్స్','grammar','all','PPT','#'),
('legacy-3','10వ తరగతి - తెలుగు వాచకం పూర్తి PDF','books','class10','PDF','#'),
('legacy-4','9వ తరగతి - డిజిటల్ వీడియో పాఠం','books','class9','URL','https://www.youtube.com/'),
('legacy-5','8వ తరగతి - తెలుగు ఉపవాచకం','books','class8','PDF','#'),
('legacy-6','7వ తరగతి - తెలుగు పండుగలు ప్రాజెక్టు','projects','project','PDF','#'),
('legacy-7','10వ తరగతి - వేయిపడగలు పుస్తక సమీక్ష','projects','review','PDF','#'),
('legacy-8','తెలుగు వార్షిక ప్రణాళిక (6-10)','plans','annual','PDF','#'),
('legacy-9','యూనిట్ ప్రణాళిక (6-10)','plans','unit','PDF','#'),
('legacy-10','పీరియడ్ ప్రణాళిక (6-10)','plans','period','PDF','#'),
('legacy-11','పోతన భాగవత రత్నాలు','literature','all','PDF','#')
ON CONFLICT (id) DO NOTHING;
