# విద్యా నిధి — Netlify Full-Stack

This version preserves the original single-file Telugu UI while moving resources out of browser localStorage/IndexedDB into Netlify Database + Netlify Blobs.

## Deploy

1. Push this folder to GitHub.
2. Import the repo into Netlify.
3. Netlify will detect `@netlify/database` and provision Netlify Database; migrations under `netlify/database/migrations/` are applied during deploy.
4. In Netlify Project configuration → Environment variables add:
   - `ADMIN_PASSWORD_HASH` = SHA-256 hex of your desired admin password
   - `ADMIN_SESSION_SECRET` = long random secret (32+ random bytes recommended)
5. Deploy.

Generate the password hash with:

```bash
node -e "const c=require('crypto'); console.log(c.createHash('sha256').update(process.argv[1]).digest('base64url'))" "YOUR_ADMIN_PASSWORD"
```

The UI never contains the admin password.

## Local

```bash
npm install
npx netlify dev
```

## Notes

- Resource metadata is stored in PostgreSQL.
- Uploaded files are stored in a site-wide Netlify Blobs store named `vidyanidhi-files`.
- The Function upload endpoint is intentionally limited to about 4.5 MB to stay below Netlify synchronous request limits. For larger PDFs/PPTs, add them as Google Drive/other external URLs in the admin form.
- Existing Google Drive/YouTube/external resources can be represented as URL resources.
